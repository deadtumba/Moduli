﻿using HashPasswords;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ConsoleApp1.Models1;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args) 
        {
            try
            {
                var dn = Helper1.GetContext();
                Autorizacia autorizacia = new Autorizacia();
                Sotrudnik sotrudnik = new Sotrudnik(); 

                Console.WriteLine("Создание новой учетной записи пользователя \n");
               
                string imya = "";
                while(string.IsNullOrEmpty(imya) || !Regex.IsMatch(imya, "^[а-яА-Я]+$"))
                {
                    Console.Write("Введите имя пользователя:");
                    imya = Console.ReadLine();
                    if (string.IsNullOrEmpty(imya) || !Regex.IsMatch(imya, "^[а-яА-Я]+$"))
                    {
                        Console.WriteLine("Некорректно введено имя, попробуйте еще раз");
                    }
                }
                sotrudnik.Imya = imya;
                string famil = "";
                while (string.IsNullOrEmpty(famil) || !Regex.IsMatch(famil, "^[а-яА-Я]+$"))
                {
                    Console.Write("Введите фамилию пользователя:");
                    famil = Console.ReadLine();
                    if (string.IsNullOrEmpty(famil) || !Regex.IsMatch(famil, "^[а-яА-Я]+$"))
                    {
                        Console.WriteLine("Некорректно введено фамилия, попробуйте еще раз");
                    }
                }
                sotrudnik.Familya = famil;
                string othes = "";
                while (string.IsNullOrEmpty(othes) || !Regex.IsMatch(othes, "^[а-яА-Я]+$"))
                {
                    Console.Write("Введите отчество пользователя:");
                    othes = Console.ReadLine();
                    if (string.IsNullOrEmpty(othes) || !Regex.IsMatch(othes, "^[а-яА-Я]+$"))
                    {
                        Console.WriteLine("Некорректно введено отчество, попробуйте еще раз");
                    }
                }
                sotrudnik.Otchestvo = othes;
                string oklad = "";
                while (string.IsNullOrEmpty(oklad) || !Regex.IsMatch(oklad, "^[0-9]+$"))
                {
                    Console.Write("Введите оклад пользователя:");
                    oklad = Console.ReadLine();
                    if (string.IsNullOrEmpty(oklad) || !Regex.IsMatch(oklad, "^[0-9]+$"))
                    {
                        Console.WriteLine("Некорректно введен оклад, попробуйте еще раз");
                    }
                }
                sotrudnik.Oklad = Convert.ToDecimal(oklad);
                string mail = "";
                while (string.IsNullOrEmpty(mail) || !Regex.IsMatch(mail, "^[a-zA-Z@.com]+$"))
                {
                    Console.Write("Введите почту пользователя:");
                    mail = Console.ReadLine();
                    if (string.IsNullOrEmpty(mail) || !Regex.IsMatch(mail, "^[a-zA-Z@.com]+$"))
                    {
                        Console.WriteLine("Некорректно введена почта, попробуйте еще раз");
                    }
                }
                sotrudnik.Email = mail;
                Console.WriteLine("Выберите должность пользователя (1 - Шахтер. 2 - Администратор. 3 - Бухгалтер. 4 - Водитель. 5 - Прораб): ");
                int dolj = Convert.ToInt32(Console.ReadLine());
                sotrudnik.ID_Doljnost = dolj;
                Console.WriteLine("Выберите пол пользователя (1 - Мужчина. 2 - Женщина.): ");
                int pol = Convert.ToInt32(Console.ReadLine());
                sotrudnik.ID_Pol = pol;
                string number = "";
                while (string.IsNullOrEmpty(number) || !Regex.IsMatch(number, "(\\+7 | 8 |\\b)[\\(\\s -]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[)\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)"))
                {
                    Console.Write("Введите телефон пользователя:");
                    number = Console.ReadLine();
                    if (string.IsNullOrEmpty(number) || !Regex.IsMatch(number, "(\\+7 | 8 |\\b)[\\(\\s -]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[)\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)"))
                    {
                        Console.WriteLine("Некорректно введен телефон, попробуйте еще раз");
                    }
                }
                sotrudnik.Nomer_telephona = number;
                string login = "";
                while (string.IsNullOrEmpty(login) || !Regex.IsMatch(login, "^[а-яА-Я0-9]+$"))
                {
                    Console.Write("Введите логин пользователя:");
                    login = Console.ReadLine();
                    if (string.IsNullOrEmpty(login) || !Regex.IsMatch(login, "^[а-яА-Я0-9]+$"))
                    {
                        Console.WriteLine("Некорректно введен логин, попробуйте еще раз");
                    }
                }
                autorizacia.Login = login;
                string passw = "";
                while (string.IsNullOrEmpty(passw) || !Regex.IsMatch(passw, "^[а-яА-Я0-9a-zA-z]+$"))
                {
                    Console.Write("Введите пароль пользователя:");
                    passw = Console.ReadLine();
                    if (string.IsNullOrEmpty(passw) || !Regex.IsMatch(passw, "^[а-яА-Я0-9a-zA-z]+$"))
                    {
                        Console.WriteLine("Некорректно введен пароль, попробуйте еще раз");
                    }
                }
                DateTime data = DateTime.Now;
                sotrudnik.Data_nachala_rabot = data.Date;
                autorizacia.ID_Sotrudnik = sotrudnik.ID_Sotrudnik;
                string hashPassword = HashPassvords.HashPassword(passw);
                Console.WriteLine("Хэшированный пароль пользователя: {0}",hashPassword);
                autorizacia.Parol = hashPassword;
                dn.Sotrudnik.Add(sotrudnik);
                dn.Autorizacia.Add(autorizacia);
                dn.SaveChanges();
                Console.WriteLine("Учетная запись успешно добавлена");
                Console.WriteLine("Нажмите Enter чтобы закончить");
                Console.ReadLine();
       

            }
            catch
            {

            }
        }
    }
}
